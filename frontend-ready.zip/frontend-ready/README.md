# 🎨 SAYU - AI 미적 정체성 발견 플랫폼

> **컬러풀한 새 디자인으로 완전히 새단장한 SAYU!**

## ✨ 새로운 기능들

### 🌈 **비주얼 업그레이드**
- **화려한 그라디언트 배경** (노랑→분홍→청록)
- **시나리오 퀴즈 미리보기** ("황혼의 미술관" 등)
- **인터랙티브 애니메이션** 및 호버 이펙트
- **반응형 모던 UI**

### 🎯 **핵심 기능**
- 🧭 **AI 큐레이터**: 개인 맞춤 미적 가이드
- 🏘️ **빌리지 시스템**: 같은 취향의 사람들과 연결
- 📊 **인사이트 대시보드**: 미적 진화 과정 추적
- 🎨 **시나리오 퀴즈**: 몰입형 아트 체험

## 🚀 빠른 배포 (Vercel)

### 1단계: 리포지토리 생성
1. GitHub에서 **새 리포지토리** 생성
2. 이 폴더의 모든 파일 업로드

### 2단계: Vercel 배포
1. [vercel.com](https://vercel.com) 접속
2. **GitHub으로 로그인**
3. **"New Project"** 클릭
4. **이 리포지토리** 선택
5. **환경변수 설정:**
   ```
   NEXT_PUBLIC_API_URL = https://valiant-nature-production.up.railway.app
   SKIP_ENV_VALIDATION = true
   ```
6. **Deploy** 클릭!

## 💡 기술 스택
- **Frontend**: Next.js 15.3.3, React 19, TypeScript
- **Styling**: Tailwind CSS v3, Framer Motion
- **Backend**: Railway (Node.js/Express)
- **Database**: PostgreSQL + Redis

## 🎨 디자인 시스템
- **SAYU 앰버**: `#FBB040`
- **SAYU 로즈**: `#F15A5A` 
- **SAYU 청록**: `#4ECDC4`
- **그라디언트**: `linear-gradient(135deg, #FBB040, #F15A5A, #4ECDC4)`

## 📱 반응형 지원
- 데스크톱, 태블릿, 모바일 완벽 지원
- PWA (Progressive Web App) 기능
- 오프라인 모드 지원

---

**🎉 이제 흑백이 아닌 컬러풀한 SAYU를 만나보세요!**